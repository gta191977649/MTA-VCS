setting = {
    usedKey = "b",
    usedCommand = "hedit",
    language = "english",
    template = "default",
    lockVehicleWhenEditing = true,
    dragmeterEnabled = true,
}
