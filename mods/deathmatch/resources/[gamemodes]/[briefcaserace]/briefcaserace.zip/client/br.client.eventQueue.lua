-- tell the server you've loaded
triggerServerEvent("onClientResourceLoad", getLocalPlayer())
